package Exceptions;

public class NoFileSelectedException extends Exception{
	public NoFileSelectedException() {
		super("No File selected");
	}
}