Inhalt des Programm-Ordners (jar-files):

1) adtlist.jar
2) adtstack.jar
3) adtqueue.jar
4) adtarray.jar



Einf�hrung:

Mittels der oben genannten jar-Dateien, wurden abstrakte
Datentypen implementiert. Um diese Nutzen zu k�nnen, folgen
Sie bitte der Installationsanleitung.



Installationsanleitung:

1) Legen Sie ein neues Java-Projekt an oder �ffnen Sie ein 
   bestehendes.

2) Binden Sie eines oder mehrere der oben genannten jars ein. Wobei folgende Abh�ngigkeiten gelten:

	adtlist.jar ben�tigt keine weitere jar
	adtstack.jar ben�tigt adtlist.jar
	adtqueue.jar ben�tigt adtstack.jar
	adtarray.jar ben�tigt adtlist.jar

3) Nun sind folgende Datentypen verf�gbar:
	adtlist.jar   -> ADTList
        adtstack.jar  -> ADTStack
	adtqueue.jar  -> ADTQueue
	adtarray.jar  -> ADTList

Viel Freude damit!
	

 