package exception;

public class PrimeNumberNotFoundException extends Exception {

}
