Einf�hrung:

Mittels des Programmes ist es m�glich die Anzahl der Vorkommen aller W�rter
in einem Text zu ermitteln und in einer log-Datei auszugeben.
Die Log-Datei wird in den selben Verzeichnispfad geschrieben, in dem sich
die Text-Datei (zum Einlesen) befindet.


Installationsanleitung:

1) �ffnen sie eine IDE (z.B. Eclipse)

2) Importieren Sie den gesamten Programm-Ordner. 

3) Wechseln Sie in das package: programm
	
	- �ndern Sie in der dortigen Main-Klasse
	  die PATH-Konstante (Pfad zur Datei)
	- Ersetzen Sie "beispiel.txt" mit dem gew�nschten
          Datei-Namen

Strategy.L = Lineares Sondierungsverfahren wird verwendet

Strategy.Q = Quadratisches Sondierungsverfahren wird verwendet

Strategy.B = DoubleHashing-Sondierungsverfahren wird verwendet
             (nach Brent)

Viel Freude damit!
	

 