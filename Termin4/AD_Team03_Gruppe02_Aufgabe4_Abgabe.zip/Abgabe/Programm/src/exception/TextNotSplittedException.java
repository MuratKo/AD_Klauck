package exception;

public class TextNotSplittedException extends Exception{

}
