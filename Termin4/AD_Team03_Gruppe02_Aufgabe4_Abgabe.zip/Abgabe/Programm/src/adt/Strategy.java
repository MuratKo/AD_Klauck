package adt;

public enum Strategy {
	L, Q, B;
}
